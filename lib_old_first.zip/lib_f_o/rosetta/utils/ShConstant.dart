String error_message_add_dealer="";

/*fonts*/
const fontRegular = 'Regular';
const fontMedium = 'Medium';
const fontSemibold = 'Semibold';
const fontBold = 'Bold';
/* font sizes*/



const textSizeVerySmall = 10.0;
const textSizeSmall = 12.0;
const textSizeSMedium = 14.0;
const textSizeMedium = 16.0;
const textSizeLargeMedium = 18.0;
const textSizeLargeMedium2 = 21.0;
const textSizeNormal = 20.0;
const textSizeXNormal = 22.0;
const textSizeLarge = 24.0;
const textSizeLarge2 = 26.0;
const textSizeXLarge = 30.0;

const height_textFormfiled = 40.0;




/* margin */

const spacing_control_half = 2.0;
const spacing_control = 4.0;
const spacing_standard = 8.0;
const spacing_middle = 10.0;
const spacing_standard_new = 16.0;
const spacing_large = 24.0;
const spacing_xlarge = 32.0;
const spacing_xxLarge = 40.0;

enum ConfirmAction { CANCEL, ACCEPT }

// const APP_FOLDER_NAME="rosetta";
const APP_FOLDER_NAME="rgallery";



// Form Search Border
const  round_border_form = 25.0;


const textWholeApp= 0.85;

//http://52.221.47.8/api/webservices/getProductPdfByColorCode
// const API_CMS_BASE_URL = "http://52.221.47.8";

const API_CMS_BASE_URL = "https://www.rosettaproducts.com";
// const API_CMS_BASE_URL = "https://rgalleries.com";
// const API_CMS_BASE_URL = "https://cmsdev.rosettaproducts.com";



//  const API_CMS_BASE_URL = "https://laravel.cppatidar.com/rosetta";
// const API_ROSDEV_BASE_URL = "http://rosdev.rosettaproducts.com";

//This is Production Server

//Rosetta India
// String API_ROS_PROD__BASE_URL = "http://ros.rosettaproducts.com";
// String API_ROS_PROD__BASE_URL_Tenants = "http://ros.rosettaproducts.com";



// //This is Development Server
String API_ROS_PROD__BASE_URL = "http://rosdev.rosettaproducts.com";
String API_ROS_PROD__BASE_URL_Tenants = "http://rosdev.rosettaproducts.com";

// R GAllery
// String API_ROS_PROD__BASE_URL = "http://ros.r-gallery.in";
// String API_ROS_PROD__BASE_URL_Tenants = "http://ros.r-gallery.in";




//pd.rosettaproducts.com
// const API_ROS_PROD__BASE_URL = "http://pd.rosettaproducts.com";

//





int pdfCount = 0;

String pdfTodayDate="";


//R gallery
String pdfIconValue ="1";

//Rosetta
// String pdfIconValue="0";

String myTimeStamp="";





//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Ios Ipa Android aok Url ~~~~~~~~~~~~~~~~~~~~~~~~~~~


//R Gallery
const APP_STORE_URL = 'https://apps.apple.com/us/app/r-gallery-india/id1628538342';
const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.rosetta.rosetta_fluter_app';


// Rosetta
// const APP_STORE_URL = 'https://apps.apple.com/us/app/rosetta-india/id1613664583';
// const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.rosetta.rosetta_fluter_app';




