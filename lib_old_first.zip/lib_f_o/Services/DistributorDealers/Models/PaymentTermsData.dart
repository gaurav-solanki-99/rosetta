class PaymentTermsData{

    String paymentTerms;
    String paymentMethods;
    String creditLimits;
    String overDueBalance;

    PaymentTermsData(this.paymentTerms, this.paymentMethods, this.creditLimits,
      this.overDueBalance);


}