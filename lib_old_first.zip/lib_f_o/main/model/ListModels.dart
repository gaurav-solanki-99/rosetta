import 'package:flutter/material.dart';

class ListModel {
  String name;
  Widget widget;

  ListModel({this.name, this.widget});
}
